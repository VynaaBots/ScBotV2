//buatan zyko-md, jgn hapus atuh 😊
let handler = async (m, { conn, usedPrefix, command }) => {
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let name = conn.getName(who)
  conn.sendButton(m.chat, `Cih Dasar Sangean`, wm, pickRandom(jahy), [['\nJadi Sange :v', `huuu`]],m)
}
handler.help = ['jahy']
handler.tags = ['nsfw']
handler.command = /^(jahy)$/i

handler.premium = true

export default handler

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

const jahy = [

   "https://cdn.discordapp.com/attachments/707201738255368194/771368472752029696/jahy_jahy_sama_wa_kujikenai_drawn_by_konbu_wakame__eb4df739bfe1edaaf865228922f56a6b.jpg",
    "https://cdn.discordapp.com/attachments/707201738255368194/771368473904676925/jahy_jahy_sama_wa_kujikenai_drawn_by_konbu_wakame__ee7cce76258c028105c26761b4843a63.jpg",
    "https://cdn.discordapp.com/attachments/707201738255368194/771368476828762152/0002.jpg",
    "https://cdn.discordapp.com/attachments/707201738255368194/771368478896422942/0012.jpg",
    "https://cdn.discordapp.com/attachments/707201738255368194/771368479612993606/jahy_jahy_sama_wa_kujikenai_drawn_by_konbu_wakame__fcd38f5dd297b4b0c412014f12fc6570.jpg",
    "https://cdn.discordapp.com/attachments/707201738255368194/771368482616639538/EVN_1_hU8AUiZAh.jpg",
    "https://cdn.discordapp.com/attachments/707201738255368194/771368480821608478/33ffb315ccc5.jpg",
    "https://cdn.discordapp.com/attachments/707201738255368194/771368482872098886/Anime-Paint-Anime-Art-Anime-Konbu-Wakame-4111984.png",
    "https://cdn.discordapp.com/attachments/707201738255368194/771368484780113960/jahy-sama-wa-kujikenai-Jahy-Konbu-Wakame-Anime-Ero-4739457.jpeg",
    "https://cdn.discordapp.com/attachments/707201738255368194/771368524001837066/yande.re_523639_animal_ears_bikini_top_cleavage_jahy_jahy-sama_wa_kujikenai_konbu_wakame_swimsuits.jpg",
    "https://cdn.discordapp.com/attachments/707201738255368194/771369268801306634/jlYrWJH.jpg",
    "https://cdn.discordapp.com/attachments/707201738255368194/771369982926913556/XQkDWwNpCqc.jpg",
    "https://cdn.discordapp.com/attachments/707201738255368194/771369987704750111/Manga_Serialization_Announcement_Illustration.png",
    "https://cdn.discordapp.com/attachments/707201738255368194/772559222084730930/16f6a933241d87f1e2228f7424fe8e94.jpg"
]