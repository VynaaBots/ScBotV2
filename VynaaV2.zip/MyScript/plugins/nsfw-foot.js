//buatan zyko-md, jgn hapus atuh 😊
let handler = async (m, { conn, usedPrefix, command }) => {
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let name = conn.getName(who)
  conn.sendButton(m.chat, `Cih Dasar Sangean`, wm, pickRandom(foot), [['\nJadi Sange :v', `huuu`]],m)
}
handler.help = ['foot']
handler.tags = ['nsfw']
handler.command = /^(foot)$/i

handler.premium = true

export default handler

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

const foot = [

    "https://konachan.com/sample/6b56f616636dee37b9cd7a3f4286bb9c/Konachan.com%20-%20316447%20sample.jpg",
    "https://konachan.com/sample/d85db565ce195e5fbc3fcc4045f80fe0/Konachan.com%20-%20313418%20sample.jpg",
    "https://cdn.discordapp.com/attachments/770948564947304448/771029453387595797/8bcdbeeb-35c8-4272-b9fd-70ddbab414c5.jpg",
    "https://cdn.discordapp.com/attachments/707201738255368194/771368482373369856/145746z8x5lw2a5l0zt055.png",
    "https://cdn.discordapp.com/attachments/707201738255368194/771368914386681926/tumblr_o4gryejrvv1uxlh2uo3_1280.png",
    "https://cdn.discordapp.com/attachments/707201738255368194/771371202752413706/ELV-Kd5WkAACqxJ.png",
    "https://cdn.discordapp.com/attachments/707201738255368194/771372528392208394/000c22cf59bb8f3b2c8e82a7b8bb9194.png",
    "https://cdn.discordapp.com/attachments/707201738255368194/771372567453892638/30a1512590925400d25bf562e5560933.png",
    "https://cdn.discordapp.com/attachments/770948564947304448/771373704030322718/dce32100-40df-44c0-b0df-a4dc8ccb2789.jpg",
    "https://cdn.discordapp.com/attachments/770948564947304448/771373796937695282/03eb6382-5be5-448e-b078-39baddb872d8.png",
    "https://cdn.discordapp.com/attachments/770948564947304448/771373820723593226/1e1e48f2-9ef3-4b3b-a9c9-241c1f4a495e.jpg",
    "https://cdn.discordapp.com/attachments/770948564947304448/771373853377036339/20170319_002303.gif",
    "https://cdn.discordapp.com/attachments/770948564947304448/771373873899110411/956487e1-e6c1-4d8d-9145-a20c30bc3a41.jpg",
    "https://cdn.discordapp.com/attachments/707201738255368194/771374024001454090/yande.png",
    "https://cdn.discordapp.com/attachments/707201738255368194/771376251931590747/Q0Vc8.png"
]