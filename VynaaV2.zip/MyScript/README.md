<p align="center">
    <img src="./media/broad1.jpg" width="100%" style="margin-left: auto;margin-right: auto;display: block;">
</p>
<h1 align="center">Yaemiko Multidevices</h1>


### 📮 S&K
1. Jangan diperjual belikan Script ini
2. Sebelum pakai jangan lupa kasih star
3. Follow Github !
4. Jangan salah gunakan script ini!

---------


## Thanks To
```bash
Author : Shirokami Ryzen 
No : +6281387307198
Thanks : Narutomo, Elaina, Ekuzika, David
Recode : Zeltoria 
